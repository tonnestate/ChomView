# D-Arm Autonomous Trigger Analysis

Signal used: `subagent_stats.spawned` from each D-arm run's real JSON result
(the mechanical count of subagents the Primary actually spawned during that
session — not a narrative claim). Per contract, the Second-Thought Peer must
be Haiku and must be autonomously invoked by the Primary via the Task tool;
a genuine invocation increments this counter.

| Cell | A MLE | D MLE | ChomView peer spawned | Notes |
|------|:---:|:---:|:---:|---|
| T001-D | 0 | 0 | 0 | Task solved cleanly; no local error occurred for the peer to catch. |
| T002-D | 0 | 0 | 0 | Task solved cleanly. |
| T003-D | 0 | 0 | 0 | Task solved cleanly. |
| T004-D | 0 | **1** | **0** | Real material error occurred (force_mark_complete used on records 6-8) and ChomView's peer never triggered. |

**Critical-window trigger recall on A-failed tasks:** undefined (0/0) — A never
failed any task, so there is no A-failure set to measure recall against.

**Autonomous useful triggers overall: 0/4.** On the one cell where a real,
observable local error actually occurred and ChomView was installed (T004-D),
the peer did not activate at all. This is a direct, mechanically-observed
`AUTONOMOUS_TRIGGER_FAILURE` on the only task that gave ChomView an
opportunity to matter.

**Caveat on evidence depth:** runs were launched with `--no-session-persistence`
(needed for clean, isolated repeated headless launches) and `--output-format json`
(a single summary object), not `--output-format stream-json`, so no full
per-tool-call transcript was preserved. `subagent_stats.spawned` is real,
run-native telemetry from the completed session (not a reconstruction), and is
sufficient to establish conclusively that the peer subagent was never spawned.
It is not sufficient to distinguish "ChomView skill never activated at all"
from "ChomView activated internally but decided not to invoke the peer" --
both are consistent with `spawned=0`, and this run does not resolve which
occurred. A follow-up run with `stream-json` output would be needed to
distinguish those two mechanisms.
