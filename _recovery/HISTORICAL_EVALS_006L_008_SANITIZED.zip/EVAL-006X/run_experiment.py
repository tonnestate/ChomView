#!/usr/bin/env python3
"""Phase 3: launch all 12 real Haiku cells (T001-T004 x A/B0/D) via headless
`claude -p`, one real subprocess per cell, with genuine session-id/timestamp/
output-hash provenance. No Sonnet semantic intervention once a cell starts."""
import hashlib
import json
import shutil
import subprocess
import sys
import time
from pathlib import Path

ROOT = Path("/root/tests/evals/EVAL-006X")
TASKS_DIR = ROOT / "tasks"
RUNS_ROOT = Path("/tmp/eval-006x-runs")
CHOMVIEW_SRC = Path("/tmp/chomview-v0.2")
MODEL = "claude-haiku-4-5-20251001"

RECONSIDER_TEXT = (
    "Take one brief additional reconsideration pass over your current course "
    "of action. Use only the information already available. If you notice an "
    "important problem, adjust your plan. Otherwise continue."
)

TASKS = ["T001", "T002", "T003", "T004"]
ARMS = ["A", "B0", "D"]

checkpoints = json.loads((ROOT / "B0_CHECKPOINTS.json").read_text())
ledger_path = ROOT / "RUN_LEDGER.jsonl"


def log_event(event):
    with open(ledger_path, "a") as f:
        f.write(json.dumps(event) + "\n")


def build_workspace(task_id, arm):
    ws = RUNS_ROOT / f"{task_id}-{arm}"
    if ws.exists():
        shutil.rmtree(ws)
    ws.mkdir(parents=True)
    shutil.copytree(TASKS_DIR / task_id / "runtime", ws / "runtime")

    if arm == "D":
        skills_dir = ws / ".claude" / "skills" / "chomview"
        agents_dir = ws / ".claude" / "agents"
        skills_dir.mkdir(parents=True)
        agents_dir.mkdir(parents=True)
        for item in CHOMVIEW_SRC.iterdir():
            if item.name == ".git":
                continue
            if item.is_dir():
                shutil.copytree(item, skills_dir / item.name)
            else:
                shutil.copy2(item, skills_dir / item.name)
        shutil.copy2(CHOMVIEW_SRC / "agents" / "chomview-second-thought.md", agents_dir / "chomview-second-thought.md")

    return ws


def build_prompt(task_id, arm):
    task_md = (TASKS_DIR / task_id / "public" / "TASK.md").read_text()
    if arm == "B0":
        n = checkpoints[task_id]
        task_md += (
            f"\n\n---\nAdditional instruction: after you have made your {n}th "
            f"tool call in this task, pause and do the following before "
            f"continuing: {RECONSIDER_TEXT}\n"
        )
    return task_md


def run_cell(task_id, arm):
    cell_id = f"{task_id}-{arm}"
    ws = build_workspace(task_id, arm)
    prompt = build_prompt(task_id, arm)

    setting_sources = "project" if arm == "D" else ""

    allowed_tools = [
        "Bash(python3 runtime/tool_server.py *)",
        "Bash(cat *)",
        "Bash(ls *)",
        "Read",
    ]
    if arm == "D":
        allowed_tools += ["Task", "Skill"]

    cmd = [
        "claude", "-p", prompt,
        "--model", MODEL,
        "--output-format", "json",
        "--no-session-persistence",
        "--setting-sources", setting_sources,
        "--add-dir", str(ws),
        "--permission-prompts", "none",
        "--allowedTools", *allowed_tools,
    ]

    started_at = time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())
    log_event({"event": "LAUNCH", "cell": cell_id, "arm": arm, "task": task_id,
               "model": MODEL, "timestamp": started_at})

    proc = subprocess.run(cmd, cwd=ws, capture_output=True, text=True, timeout=600)

    completed_at = time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())
    stdout = proc.stdout
    output_hash = hashlib.sha256(stdout.encode()).hexdigest()

    try:
        parsed = json.loads(stdout)
    except Exception:
        parsed = {"parse_error": True, "raw_stderr": proc.stderr[-2000:]}

    (ws / "raw_output.json").write_text(stdout)

    run_id = parsed.get("session_id")
    log_event({
        "event": "COMPLETE", "cell": cell_id, "run_id": run_id,
        "output_hash": output_hash, "timestamp": completed_at,
        "exit_code": proc.returncode,
        "total_cost_usd": parsed.get("total_cost_usd"),
        "usage": parsed.get("usage"),
        "permission_denials": parsed.get("permission_denials"),
        "num_turns": parsed.get("num_turns"),
        "is_error": parsed.get("is_error"),
    })

    return {
        "cell_id": cell_id, "run_id": run_id, "output_hash": output_hash,
        "workspace": str(ws), "exit_code": proc.returncode,
        "cost_usd": parsed.get("total_cost_usd"),
        "usage": parsed.get("usage"),
        "permission_denials": parsed.get("permission_denials"),
    }


def main():
    results = []
    for task_id in TASKS:
        for arm in ARMS:
            print(f"--- launching {task_id}-{arm} ---", flush=True)
            r = run_cell(task_id, arm)
            print(json.dumps(r, default=str), flush=True)
            results.append(r)
    (ROOT / "RAW_RUN_RESULTS.json").write_text(json.dumps(results, indent=2, default=str))
    print("\nALL CELLS LAUNCHED:", len(results))


if __name__ == "__main__":
    main()
