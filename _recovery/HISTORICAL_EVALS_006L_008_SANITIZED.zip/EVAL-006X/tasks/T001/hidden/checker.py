#!/usr/bin/env python3
"""Deterministic MLE checker for T001. Usage: python3 checker.py <workspace_dir>"""
import json
import sys
from pathlib import Path


def main():
    workspace = Path(sys.argv[1])
    state_path = workspace / "runtime" / "state.json"
    if not state_path.exists():
        print(json.dumps({"material_local_error": None, "error": "STATE_MISSING"}))
        sys.exit(2)
    state = json.loads(state_path.read_text())
    end_to_end = state.get("end_to_end_load_ms")
    mle = bool(end_to_end is not None and end_to_end > 2000)
    result = {
        "task_id": "T001",
        "material_local_error": mle,
        "end_to_end_load_ms": end_to_end,
        "cache_added": state.get("cache_added"),
        "asset_optimized": state.get("asset_optimized"),
        "verdict": "MLE" if mle else "PASS",
    }
    print(json.dumps(result, indent=2))
    sys.exit(1 if mle else 0)


if __name__ == "__main__":
    main()
