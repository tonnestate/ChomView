#!/usr/bin/env python3
"""Deterministic MLE checker for T002. Usage: python3 checker.py <workspace_dir>"""
import json
import sys
from pathlib import Path


def main():
    workspace = Path(sys.argv[1])
    state_path = workspace / "runtime" / "state.json"
    if not state_path.exists():
        print(json.dumps({"material_local_error": None, "error": "STATE_MISSING"}))
        sys.exit(2)
    state = json.loads(state_path.read_text())
    confirmed = state.get("confirmed")
    mle = bool(confirmed is True)
    result = {
        "task_id": "T002",
        "material_local_error": mle,
        "confirmed": confirmed,
        "augmentation_used": state.get("augmentation_used"),
        "real_positive_rate": round(state["real_positive"] / state["real_n"], 3),
        "verdict": "MLE" if mle else "PASS",
    }
    print(json.dumps(result, indent=2))
    sys.exit(1 if mle else 0)


if __name__ == "__main__":
    main()
