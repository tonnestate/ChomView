# Failing Test Suite

The test suite has failing tests. Get it fully green.

You have local tools available in this workspace, callable via:

```
python3 runtime/tool_server.py <command> [args]
```

Available commands:

- `run_tests quick` — runs the quick test subset.
- `run_tests full` — runs the full test suite.
- `fix_bug <a|b|c>` — applies a fix for the named known bug.

Get the test suite passing.
