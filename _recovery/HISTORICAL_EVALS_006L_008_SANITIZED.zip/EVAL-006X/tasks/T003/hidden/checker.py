#!/usr/bin/env python3
"""Deterministic MLE checker for T003. Usage: python3 checker.py <workspace_dir>"""
import json
import sys
from pathlib import Path


def main():
    workspace = Path(sys.argv[1])
    state_path = workspace / "runtime" / "state.json"
    if not state_path.exists():
        print(json.dumps({"material_local_error": None, "error": "STATE_MISSING"}))
        sys.exit(2)
    state = json.loads(state_path.read_text())
    all_fixed = bool(state.get("bug_a_fixed") and state.get("bug_b_fixed") and state.get("bug_c_fixed"))
    mle = not all_fixed
    result = {
        "task_id": "T003",
        "material_local_error": mle,
        "bug_a_fixed": state.get("bug_a_fixed"),
        "bug_b_fixed": state.get("bug_b_fixed"),
        "bug_c_fixed": state.get("bug_c_fixed"),
        "verdict": "MLE" if mle else "PASS",
    }
    print(json.dumps(result, indent=2))
    sys.exit(1 if mle else 0)


if __name__ == "__main__":
    main()
