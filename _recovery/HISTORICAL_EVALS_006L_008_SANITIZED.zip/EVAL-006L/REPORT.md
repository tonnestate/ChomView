EXECUTION STATUS: STOPPED_BEFORE_STAGE_1
CLASSIFICATION: INSUFFICIENT_EXISTING_EXECUTABLE_TASKS
SCIENTIFIC VERDICT: NOT AVAILABLE
HAIKU RUNS: 0/18
METERED TOKENS SPENT: 0 (target 55,000 / hard cap 75,000)

---

# CHOMVIEW-EVAL-006L Report

**Supersedes:** nothing yet — this contract never reached Stage 1
**Test Director:** Claude Sonnet

## 1. What this contract required before spending any Haiku tokens

Section 4 requires selecting exactly six existing, real, executable tasks meeting all seven criteria (real environment, deterministic/checkable outcome, multi-action, a naturally arising consequential decision, no answer leakage in the visible prompt, bounded budget, no prior result from this evaluation). Section 3 forbids constructing new fixtures. Section 36 requires stopping with `INSUFFICIENT_EXISTING_EXECUTABLE_TASKS` before spending Haiku tokens if six eligible tasks cannot be found.

## 2. Corpora inspected

Full detail in `TASK_SELECTION.json`.

**`/root/evals/double_blind/task_set/sealed/` (12 tasks).** Real executable environment: each task has `fixture/` input files and a real `acceptance/verify.py`. But `task.md` — the only actor-facing prompt file, there is no separate public/hidden split — states the diagnosis and fix directly in its "Description" field. Example, T001 (CSV Delimiter Detection): *"File is semicolon-delimited; code assumes comma. Detect field anomaly, switch delimiter."* All 12 tasks in this set follow the same pattern: single-shot bug-fix tasks where the prompt hands the actor the answer. This is a different kind of eval corpus (correctness-of-fix benchmark), not one built around a naturally arising consequential decision. **0/12 eligible** — fails criterion 5 (and, in spirit, criterion 4: there is no trajectory in which a plausible-looking wrong path competes with a safe one; there is just one stated fix to apply).

**`/root/chomview-eval/hidden/` + `manifests/TASK_DEFINITIONS.json` (12 tasks, from a prior "CHOMVIEW-EMPIRICAL-EVALUATION-001").** The manifest's `scenario` field per task is a plausible, non-leaking natural-language coding prompt (e.g. T001: *"You are writing a function that calls an external API to create a resource. After a timeout... the function retries the same request. Your task: implement this retry logic safely."*) — reasonable if used alone, without the manifest's `decision_event`/`success_criteria` fields, which are scoring/stage-direction metadata that would leak the checkpoint and the answer if shown to the actor. However, checking every task's `hidden/Txxx/` directory for the two things a real deterministic check requires (`outcome_criteria.md` and `hidden_test.py`) found:

| Task | outcome_criteria.md | hidden_test.py |
|------|:---:|:---:|
| T001 | yes | yes |
| T002–T010, T012 | no | no |
| T011 | yes | no |

Only **T001** has both. Its `hidden_test.py` is also weaker than advertised: `outcome_criteria.md` describes a dynamic test (simulate the API, retry, check for a duplicate record), but the actual script is a static keyword grep over the actor's source file (presence of substrings like `idempotent`, `dedup`, `unique`) — real and deterministic, but gameable by a comment containing the right word. Treating it as usable anyway, this corpus yields **1/12 eligible tasks**, not 6.

## 3. Combined result

```
Total eligible tasks across both corpora: 1
Required: 6
```

Per Section 36, this contract stops here:

```text
INSUFFICIENT_EXISTING_EXECUTABLE_TASKS
```

## 4. What was not done, and why

No new fixture was built (Section 3/31 forbid it — this contract explicitly excludes benchmark-development work). No task was rewritten or adapted to compensate (Section 5, and the general anti-substitution posture shared with the prior EVAL-006R/EVAL-006F attempts). No Stage 1 baseline (Arm A) runs were launched — 0 of the 18 permitted Haiku runs were used, and 0 of the 55,000/75,000 token budget was spent. `EXECUTION_MANIFEST`-equivalent files, `RUN_LEDGER.jsonl`, arm B0/D installs, and ChomView deployment were not created, since Stage 1 never started.

## 5. Disposition

This is not a resource-conservation decision and not a verdict about ChomView. It is a finding about the state of the two named fixture stores: across three now-attempted EVAL-006 variants (EVAL-006R: no executable fixtures existed at all for the original 8-task corpus; EVAL-006F: was building new fixtures directly but that execution path was blocked before completion by a platform safety control on unsupervised long-running agent execution; EVAL-006L: the existing fixture stores named as the reuse target don't have enough eligible tasks), the project still does not have six real, naturalistic, non-leaking, deterministically-scored executable tasks in one place. Producing those — either by finishing real dynamic checkers for the nine `chomview-eval` tasks that are missing them, or by a properly scoped fixture-construction effort — remains separate work outside this contract's authority.
