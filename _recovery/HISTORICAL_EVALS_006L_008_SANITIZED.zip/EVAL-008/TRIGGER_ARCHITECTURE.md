# TRIGGER_ARCHITECTURE.md

## Actual execution path observed (from all prior EVAL-006X/006X-REPAIR evidence)

```
Primary session starts, cwd = workspace with .claude/skills/chomview/ +
.claude/agents/chomview-second-thought.md
        |
        v
system/init lists "chomview" in `skills` and "chomview-second-thought" in
`agents` (confirmed: RUNTIME_DISCOVERY.json, PASS)
        |
        v
Primary works the task via Bash tool calls against runtime/tool_server.py
        |
        v
[NOTHING deterministic ever inspects these tool calls for ChomView-relevance]
        |
        v
Primary reaches its own final response. Only IF the primary's own free-form
judgment, reading the Skill tool's one-line description in its own context,
decides "this looks like a case for chomview" does it ever call the Skill
tool at all.
        |
        v
Observed: this judgment call fires 0/4 (naturalistic), 0/2 (ideal-condition
smoke test). When invocation is made MANDATORY by explicit instruction, the
Skill tool is called, but resolves via SELF_FALLBACK rather than spawning
the real peer (0/4 real peer spawns even under mandatory invocation).
```

## Answering Section 6's concrete questions

- **What causes ChomView to be considered?** Nothing deterministic. Purely
  the Primary's own judgment reading the Skill's description string in its
  system prompt, competing against ~17 other unrelated skill descriptions
  in this environment (per RUNTIME_DISCOVERY.json's caveat).
- **What causes SKILL.md to be loaded?** The model choosing to call the
  `Skill` tool with `skill: "chomview"`. Nothing else loads it.
- **What decides a local decision is consequential?** Nothing at the
  runtime/deterministic layer. Entirely delegated to the Primary's own
  in-context judgment, with no candidate-detection layer in front of it.
- **What actually invokes the peer?** The Primary would need to separately
  call the `Task` tool with `subagent_type: "chomview-second-thought"`.
  This is a SECOND independent judgment call, after the first, and observed
  evidence shows the model doesn't take this second step on its own even
  when it does take the first (self-fallback instead).
- **Deterministic vs. model-spontaneous?** 100% model-spontaneous, at TWO
  separate decision points (invoke skill; then separately invoke peer).
  There is no deterministic runtime component anywhere in this chain.

## Conclusion

This is a pure **Path-1-style, model-invoked** trigger with no deterministic
layer at all, confirming this is the actual, sole failure surface -- not
peer quality (already shown good, `FORCED_PEER_TEST`), not installation
(PASS), not discovery (PASS).
