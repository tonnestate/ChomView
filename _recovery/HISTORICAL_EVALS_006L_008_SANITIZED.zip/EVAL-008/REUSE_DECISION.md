# Reuse Decision (Section 8/9)

Inspected before building anything custom: Claude Code's native hook system
(`.claude/settings.json` `hooks.PreToolUse`, matcher-scoped to `Bash`,
running a command that receives the tool call as JSON on stdin and can
block the call via exit code 2, feeding stderr back to the model as the
tool's error/context). This is an existing runtime mechanism, not new
orchestration infrastructure -- the only custom code is a ~30-line
candidate-pattern detector script.

**Path selected: PATH 2 (Hybrid Trigger).** Cheap deterministic candidate
detection (the hook, regex-matching Bash commands against narrow
Section-11 categories) gates whether the Primary is prompted at all; the
Primary retains full semantic judgment about whether and how to act on
that prompt (it chose to invoke a real Task-tool peer rather than being
forced to). This preserves Section 12's "avoid keyword-only triggering"
requirement -- the hook only ever *proposes* a candidate event, and never
itself decides the outcome or invokes the peer; the model does that.

Path 1 (pure model-invoked) was already proven insufficient by direct
observation (EVAL-006X-REPAIR). Path 3 (fully external, runtime invokes
ChomView directly with no model judgment) was rejected because it would
remove the semantic-relevance step the skill's own design depends on, and
because the contract's Section 12 explicitly warns against pure mechanical
triggering.
