#!/usr/bin/env python3
"""Section 17: 6 independent autonomous D-AUTO runs on clean T004 resets.
No manual trigger, no forced peer, no Sonnet intervention. Frozen hook +
skill + peer only."""
import json, shutil, subprocess, time
from pathlib import Path

TASKS_DIR = Path("/root/tests/evals/EVAL-006X/tasks")
CHOMVIEW_SRC = Path("/tmp/chomview-v0.2.0-verified")
OUT_ROOT = Path("/root/tests/evals/EVAL-008/runs")
MODEL = "claude-haiku-4-5-20251001"
HOOK_PATH = "/root/tests/evals/EVAL-008/chomview_trigger_hook.py"

def build_workspace(idx):
    ws = OUT_ROOT / f"T004-DAUTO{idx}"
    if ws.exists():
        shutil.rmtree(ws)
    ws.mkdir(parents=True)
    shutil.copytree(TASKS_DIR / "T004" / "runtime", ws / "runtime")
    skills_dir = ws / ".claude" / "skills" / "chomview"
    agents_dir = ws / ".claude" / "agents"
    skills_dir.mkdir(parents=True)
    agents_dir.mkdir(parents=True)
    for item in CHOMVIEW_SRC.iterdir():
        if item.name == ".git":
            continue
        if item.is_dir():
            shutil.copytree(item, skills_dir / item.name)
        else:
            shutil.copy2(item, skills_dir / item.name)
    shutil.copy2(CHOMVIEW_SRC / "agents" / "chomview-second-thought.md", agents_dir / "chomview-second-thought.md")
    (ws / ".claude" / "settings.json").write_text(json.dumps({
        "hooks": {"PreToolUse": [{"matcher": "Bash", "hooks": [{"type": "command", "command": f"python3 {HOOK_PATH}"}]}]}
    }))
    return ws

def run_cell(idx):
    ws = build_workspace(idx)
    prompt = (TASKS_DIR / "T004" / "public" / "TASK.md").read_text()
    cmd = [
        "claude", "-p", prompt,
        "--model", MODEL,
        "--output-format", "stream-json", "--forward-subagent-text", "--include-hook-events", "--verbose",
        "--no-session-persistence",
        "--setting-sources", "project",
        "--add-dir", str(ws),
        "--permission-prompts", "none",
        "--allowedTools", "Bash(python3 runtime/tool_server.py *)", "Task", "Skill", "Read",
    ]
    started = time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())
    proc = subprocess.run(cmd, cwd=ws, capture_output=True, text=True, timeout=300)
    completed = time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())
    (ws / "raw_stream.jsonl").write_text(proc.stdout)
    (ws / "stderr.log").write_text(proc.stderr)
    return {"idx": idx, "started": started, "completed": completed, "exit_code": proc.returncode, "workspace": str(ws)}

if __name__ == "__main__":
    results = []
    for i in range(1, 7):
        print(f"--- T004-DAUTO{i} ---", flush=True)
        r = run_cell(i)
        print(json.dumps(r), flush=True)
        results.append(r)
    (OUT_ROOT.parent / "RUN_META_DAUTO.json").write_text(json.dumps(results, indent=2))
