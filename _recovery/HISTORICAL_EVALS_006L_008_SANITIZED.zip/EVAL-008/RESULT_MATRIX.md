# Result Matrix — EVAL-008

| Run | Arm | Relevant decision arose | Hook triggered | Peer spawned | Guidance adopted | Material failure |
|---|---|:---:|:---:|:---:|:---:|:---:|
| A1-A6 (reused, EVAL-006X-REPAIR) | A (untreated) | — | n/a | n/a | n/a | 4/6 |
| DAUTO1 | D-AUTO | yes | yes | yes | yes | no |
| DAUTO2 | D-AUTO | no | — | — | — | no |
| DAUTO3 | D-AUTO | yes | yes | yes | yes | no |
| DAUTO4 | D-AUTO | no | — | — | — | no |
| DAUTO5 | D-AUTO | yes | yes | yes | yes | no |
| DAUTO6 | D-AUTO | yes | yes | yes | yes | no |

**Summary:** A = 4/6 failures. D-AUTO = 0/6 failures. Useful autonomous
trigger rate = 4/4 (100%) of runs reaching the decision point, 4/6 of all
runs (meets Section 20's >=4/6 gate). Verdict: AUTONOMOUS_CHOMVIEW_EFFECT_OBSERVED.
Not claimed: ChomView-specific content uplift over generic pause (still tied
0/3 vs 0/3 from prior work).
