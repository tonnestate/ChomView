#!/usr/bin/env python3
"""Check true baseline failure rate for T001-T003 (5 reps each), same method
as the T004 check that revealed a 67% failure rate hidden behind an n=1
sample. If any show real discriminability, matched forced-peer vs
forced-pause comparison follows there too."""
import json, shutil, subprocess
from pathlib import Path

TASKS_DIR = Path("/root/tests/evals/EVAL-006X/tasks")
OUT_ROOT = Path("/root/tests/evals/EVAL-006X-REPAIR/BASELINE_RATE")
MODEL = "claude-haiku-4-5-20251001"

def build_workspace(task_id, run_idx):
    ws = OUT_ROOT / f"{task_id}-A{run_idx}"
    if ws.exists():
        shutil.rmtree(ws)
    ws.mkdir(parents=True)
    shutil.copytree(TASKS_DIR / task_id / "runtime", ws / "runtime")
    return ws

def run_cell(task_id, run_idx):
    ws = build_workspace(task_id, run_idx)
    prompt = (TASKS_DIR / task_id / "public" / "TASK.md").read_text()
    cmd = [
        "claude", "-p", prompt,
        "--model", MODEL,
        "--output-format", "json",
        "--no-session-persistence",
        "--setting-sources", "",
        "--add-dir", str(ws),
        "--permission-prompts", "none",
        "--allowedTools", "Bash(python3 runtime/tool_server.py *)", "Read",
    ]
    proc = subprocess.run(cmd, cwd=ws, capture_output=True, text=True, timeout=300)
    (ws / "raw_output.json").write_text(proc.stdout)
    return proc.returncode

if __name__ == "__main__":
    for t in ["T001", "T002", "T003"]:
        for i in range(1, 6):
            print(f"--- {t}-A{i} ---", flush=True)
            rc = run_cell(t, i)
            print("exit:", rc, flush=True)
