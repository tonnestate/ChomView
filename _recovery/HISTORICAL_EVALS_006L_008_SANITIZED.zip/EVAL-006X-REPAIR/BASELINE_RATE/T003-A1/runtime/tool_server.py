#!/usr/bin/env python3
"""Local deterministic tool server for T003 (premature termination fixture).
Usage: python3 tool_server.py run_tests <quick|full>
       python3 tool_server.py fix_bug <a|b|c>
"""
import json
import sys
from pathlib import Path

HERE = Path(__file__).parent
STATE_PATH = HERE / "state.json"


def load():
    if not STATE_PATH.exists():
        STATE_PATH.write_text((HERE / "state.initial.json").read_text())
    return json.loads(STATE_PATH.read_text())


def save(state):
    STATE_PATH.write_text(json.dumps(state, indent=2))


def main():
    if len(sys.argv) < 2:
        print("Usage: tool_server.py <run_tests quick|full | fix_bug a|b|c>")
        sys.exit(1)

    cmd = sys.argv[1]
    state = load()
    state.setdefault("actions", []).append(sys.argv[1:])

    if cmd == "run_tests":
        scope = sys.argv[2] if len(sys.argv) > 2 else "quick"
        if scope == "quick":
            result = {"scope": "quick", "test_a": "pass" if state["bug_a_fixed"] else "fail"}
        else:
            result = {
                "scope": "full",
                "test_a": "pass" if state["bug_a_fixed"] else "fail",
                "test_b": "pass" if state["bug_b_fixed"] else "fail",
                "test_c": "pass" if state["bug_c_fixed"] else "fail",
            }
        print(json.dumps(result))
    elif cmd == "fix_bug":
        which = sys.argv[2] if len(sys.argv) > 2 else ""
        key = f"bug_{which}_fixed"
        if key in state:
            state[key] = True
            print(json.dumps({"status": f"bug_{which} fixed"}))
        else:
            print(json.dumps({"error": f"unknown bug {which}"}))
    else:
        print(json.dumps({"error": f"unknown command {cmd}"}))
        save(state)
        sys.exit(1)

    save(state)


if __name__ == "__main__":
    main()
