#!/usr/bin/env python3
"""Explicit-invocation value test: does ChomView's STP add value WHEN CONSULTED,
independent of whether it autonomously triggers? Not the D2 experimental arm --
a separate diagnostic, per ChomView's own stated research priority
(activation-cues.md: 'first question is whether the STP adds value when
invoked; routing sophistication should come later')."""
import json
import shutil
import subprocess
import time
from pathlib import Path

TASKS_DIR = Path("/root/tests/evals/EVAL-006X/tasks")
CHOMVIEW_SRC = Path("/tmp/chomview-v0.2.0-verified")
OUT_ROOT = Path("/root/tests/evals/EVAL-006X-REPAIR/EXPLICIT_INVOCATION_TEST")
MODEL = "claude-haiku-4-5-20251001"

EXPLICIT_INSTRUCTION = (
    "\n\n---\nBefore you finish this task, you MUST explicitly invoke the "
    "`chomview` skill (via the Skill tool) to get a Second-Thought Peer "
    "review of the most consequential decision you made in this task. "
    "Actually use the tool -- do not just describe what it might say. "
    "Seriously consider its feedback, and adjust your final actions if it "
    "identifies a real problem. Then finish the task."
)

def build_workspace(task_id):
    ws = OUT_ROOT / f"{task_id}-E"
    if ws.exists():
        shutil.rmtree(ws)
    ws.mkdir(parents=True)
    shutil.copytree(TASKS_DIR / task_id / "runtime", ws / "runtime")
    skills_dir = ws / ".claude" / "skills" / "chomview"
    agents_dir = ws / ".claude" / "agents"
    skills_dir.mkdir(parents=True)
    agents_dir.mkdir(parents=True)
    for item in CHOMVIEW_SRC.iterdir():
        if item.name == ".git":
            continue
        if item.is_dir():
            shutil.copytree(item, skills_dir / item.name)
        else:
            shutil.copy2(item, skills_dir / item.name)
    shutil.copy2(CHOMVIEW_SRC / "agents" / "chomview-second-thought.md", agents_dir / "chomview-second-thought.md")
    return ws

def run_cell(task_id):
    ws = build_workspace(task_id)
    task_md = (TASKS_DIR / task_id / "public" / "TASK.md").read_text()
    prompt = task_md + EXPLICIT_INSTRUCTION

    cmd = [
        "claude", "-p", prompt,
        "--model", MODEL,
        "--output-format", "stream-json", "--forward-subagent-text", "--verbose",
        "--no-session-persistence",
        "--setting-sources", "project",
        "--add-dir", str(ws),
        "--permission-prompts", "none",
        "--allowedTools", "Bash(python3 runtime/tool_server.py *)", "Task", "Skill", "Read",
    ]
    started = time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())
    proc = subprocess.run(cmd, cwd=ws, capture_output=True, text=True, timeout=300)
    completed = time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())
    (ws / "raw_stream.jsonl").write_text(proc.stdout)
    (ws / "stderr.log").write_text(proc.stderr)
    return {"task_id": task_id, "started": started, "completed": completed, "exit_code": proc.returncode, "workspace": str(ws)}

if __name__ == "__main__":
    results = []
    for t in ["T001", "T002", "T003", "T004"]:
        print(f"--- {t}-E ---", flush=True)
        r = run_cell(t)
        print(json.dumps(r), flush=True)
        results.append(r)
    (OUT_ROOT / "RUN_META.json").write_text(json.dumps(results, indent=2))
