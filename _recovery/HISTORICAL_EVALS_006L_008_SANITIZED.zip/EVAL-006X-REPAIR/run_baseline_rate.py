#!/usr/bin/env python3
"""Establish T004's true unaided baseline failure rate: plain task, no
ChomView, no forced pause, no peer -- just the A-arm condition, repeated,
to contextualize the forced-peer vs forced-pause tie (3/3 vs 3/3, n=3)."""
import json, shutil, subprocess
from pathlib import Path

TASKS_DIR = Path("/root/tests/evals/EVAL-006X/tasks")
OUT_ROOT = Path("/root/tests/evals/EVAL-006X-REPAIR/BASELINE_RATE")
MODEL = "claude-haiku-4-5-20251001"

def build_workspace(run_idx):
    ws = OUT_ROOT / f"T004-A{run_idx}"
    if ws.exists():
        shutil.rmtree(ws)
    ws.mkdir(parents=True)
    shutil.copytree(TASKS_DIR / "T004" / "runtime", ws / "runtime")
    return ws

def run_cell(run_idx):
    ws = build_workspace(run_idx)
    prompt = (TASKS_DIR / "T004" / "public" / "TASK.md").read_text()
    cmd = [
        "claude", "-p", prompt,
        "--model", MODEL,
        "--output-format", "json",
        "--no-session-persistence",
        "--setting-sources", "",
        "--add-dir", str(ws),
        "--permission-prompts", "none",
        "--allowedTools", "Bash(python3 runtime/tool_server.py *)", "Read",
    ]
    proc = subprocess.run(cmd, cwd=ws, capture_output=True, text=True, timeout=300)
    (ws / "raw_output.json").write_text(proc.stdout)
    return {"run": run_idx, "exit_code": proc.returncode}

if __name__ == "__main__":
    for i in range(1, 6):
        print(f"--- T004-A{i} ---", flush=True)
        r = run_cell(i)
        print(json.dumps(r), flush=True)
