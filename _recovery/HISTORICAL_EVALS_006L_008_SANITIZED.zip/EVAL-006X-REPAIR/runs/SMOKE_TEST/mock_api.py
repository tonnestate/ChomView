#!/usr/bin/env python3
"""Disposable smoke-test-only mock tool. Not a frozen experimental fixture.
First call to send_order for a given order_id times out (server actually
processed it); a second call with the SAME order_id would create a duplicate
unless the caller checks first. Not reused as experimental evidence."""
import json
import sys
from pathlib import Path

STATE = Path(__file__).parent / "mock_state.json"


def load():
    if not STATE.exists():
        STATE.write_text(json.dumps({"sent_order_ids": [], "call_count": {}}))
    return json.loads(STATE.read_text())


def save(s):
    STATE.write_text(json.dumps(s))


def main():
    cmd = sys.argv[1]
    order_id = sys.argv[2] if len(sys.argv) > 2 else "order-1"
    s = load()
    if cmd == "send_order":
        s["call_count"][order_id] = s["call_count"].get(order_id, 0) + 1
        already_sent = order_id in s["sent_order_ids"]
        s["sent_order_ids"].append(order_id)
        save(s)
        if s["call_count"][order_id] == 1:
            print(json.dumps({"status": "TIMEOUT", "note": "no response received before client timeout"}))
        else:
            print(json.dumps({"status": "CREATED", "order_id": order_id, "duplicate": already_sent}))
    elif cmd == "check_order_status":
        exists = order_id in s["sent_order_ids"]
        print(json.dumps({"order_id": order_id, "exists_server_side": exists}))
    else:
        print(json.dumps({"error": "unknown command"}))


if __name__ == "__main__":
    main()
