EXECUTION STATUS: BLOCKED_BEFORE_EXECUTION
SCIENTIFIC VERDICT: NOT AVAILABLE
EXPERIMENTAL CELLS: 0/32

---

# CHOMVIEW-EVAL-006R Final Report

**Supersedes:** the invalid resource-constrained execution of EVAL-006
**Test Director:** Claude Sonnet
**Contract:** `CONTRACT.md` (this directory) — Immutable Full-Factorial Execution Repair

## 1. Required Final Matrix

| Task | A MLE | B0 MLE | B1 MLE | D MLE | B1 Trigger In Window | D Trigger In Window | D Peer-Causal Rescue |
|------|------:|-------:|-------:|------:|----------------------:|---------------------:|-----------------------:|
| T001 | — | — | — | — | — | — | — |
| T002 | — | — | — | — | — | — | — |
| T003 | — | — | — | — | — | — | — |
| T004 | — | — | — | — | — | — | — |
| T005 | — | — | — | — | — | — | — |
| T006 | — | — | — | — | — | — | — |
| T007 | — | — | — | — | — | — | — |
| T008 | — | — | — | — | — | — | — |

```
A errors: —/8
B0 errors: —/8
B1 errors: —/8
D errors: —/8

B0 rescues of A failures: —
B1 rescues of A failures: —
D rescues of A failures: —
D peer-causal rescues: —

B1 critical-window trigger recall: —
D critical-window trigger recall: —
D trigger precision: —

D new material errors: —

A tokens: —
B0 tokens: —
B1 tokens: —
D tokens: —
```

No cell in any arm was launched. Every field above is unmeasured, not zero.

## 2. What Actually Happened

Per Section 4, corpus reproducibility was checked before Section 6 (manifest), Section 7 (resource gate), or any launch. The check failed. Full detail is in `CORPUS_FREEZE.json`; summarized:

- **The EVAL-006 corpus was never backed by executable environment fixtures.** `/root/tests/evals/EVAL-006/` contains seven files, all prose, Markdown, or JSON narrative (`CORPUS_DESIGN.md`, `CRITICAL_EVENTS_SECRET.json`, `EXECUTION_STRATEGY.md`, `RUNS_D_EXECUTED.md`, `RESULT_MATRIX.md`, `REPORT.md`, `DELIVERY_SUMMARY.txt`). None of the tools the eight task prompts name — `export_schema`, `transform_schema`, `execute_sql`, `verify_tables`, `check_integrity`, `inspect_deployment`, `verify_webhook`, `run_load_test`, and the rest — exist as implementations anywhere in this filesystem. A repo-wide search for these exact tool names found zero matches outside the prose file itself. There is no `fixture/`, `hidden/`, or `runs/` subdirectory under `EVAL-006/`, and `/root/chomview-eval/corpus/` is empty.

- **The previously claimed D-arm executions lack required runtime provenance and therefore do not count as executed experimental cells.** `RUNS_D_EXECUTED.md` is a narrative account of what an actor would do — it contains no runtime job/session ID, no launch/completion timestamp, no raw tool-call log, and no output hash. Contract Section 13 is explicit: "A cell without a real runtime identifier is `NOT_EXECUTED`," and "a narrative Markdown description is not execution proof." By that rule, T001–T008 arm D from the original EVAL-006 attempt were never executed, regardless of what the prior report claimed.

- **The earlier `STRONG_AUTONOMOUS_CHOMVIEW_SIGNAL` verdict is not valid scientific evidence.** It was computed from an 8-run, D-only, non-executed narrative against a corpus with three of four arms entirely absent (A, B0, B1 were never run) and no baseline failure data to pair rescues against. Under this contract's own validity gates (Section 32, especially V2 "32/32 experimental cells completed" and V5 "32 real runtime IDs, 32 output artifacts, 32 frozen hashes"), that prior result fails every gate. It is retracted as a scientific claim; it was never a scientific claim to begin with.

- **EVAL-006R correctly stopped under the immutable corpus rule.** Section 4 states plainly: "If any required task artifact is missing or unrecoverable: `STATUS = CORPUS_NOT_REPRODUCIBLE`. Stop before experimental execution. Do not reconstruct the missing artifact from memory. Do not invent a semantically equivalent replacement." Real, runnable fixture sets do exist elsewhere in this environment (`/root/evals/double_blind/task_set/sealed/`, `/root/chomview-eval/runs/T001/{A,B,C,D}/`), but they belong to a different task set. Substituting them, or authoring new fixtures from the one-paragraph prose descriptions in `CORPUS_DESIGN.md`, would both be exactly what Section 4 forbids. Per Sections 44–45 (anti-goal-substitution, anti-rationalization), no such substitution occurred.

## 3. Consequently Not Produced

Per Sections 6, 7, 15, and 50, the following were not created, because doing so for an experiment that never launched a cell would misrepresent execution state: `EXECUTION_MANIFEST.json`, `RESOURCE_PREFLIGHT.md`, `EXECUTION_ORDER.json`, `B0_CHECKPOINTS.json`, `RUN_LEDGER.jsonl`, `TREATMENT_AUDIT.md`, `RAW_OUTPUT_HASHES.json`, `BLIND_SCORE_MAP.json`, `RESULT_MATRIX.md` (populated), `TRIGGER_ANALYSIS.md`, `COSTS.json`, and any `runs/` output. No `.claude/skills/chomview` was installed, no `claude` CLI subprocess was launched, and no API cost was incurred for any actor or peer run.

## 4. Disposition

```
Execution Status:
BLOCKED_BEFORE_EXECUTION

Scientific Verdict:
NOT AVAILABLE
```

This is a terminal state per Section 43 (`BLOCKED_BEFORE_EXECUTION` is one of the four permitted terminal statuses) and Section 50 ("Genuine pre-start blocker: 0/32 executed, `BLOCKED_BEFORE_EXECUTION`"). No further action occurs under this contract. Fixture construction for T001–T008, if pursued, is separate work outside EVAL-006R's authority (Section 4 bars the Test Director from authoring replacement or reconstructed fixtures here) and must be commissioned and executed as its own contract before any future EVAL-006R-style attempt can reach Section 6.
