# CHOMVIEW-EVAL-006R

## Immutable Full-Factorial Execution Repair

**Status:** EXECUTION CONTRACT
**Supersedes:** the invalid resource-constrained execution of EVAL-006
**Scientific question:** unchanged from EVAL-006
**ChomView version:** v0.2.0
**Pinned ChomView commit:** `73c4d30238b919e0d0421e340ffdcc3ef5b02ba8`
**Test Director:** Claude Sonnet
**Experimental actor model:** Claude Haiku, identical version in every experimental cell
**ChomView peer model:** same Claude Haiku version as Primary
**Required experimental cells:** 32/32

---

# 1. Mission

Execute the originally intended EVAL-006 experiment without redesigning it.

The scientific question is:

> Can ChomView autonomously recognize a consequential local decision during a natural Haiku task trajectory, intervene before commitment, and reduce material local errors relative to both untreated Haiku and a semantics-blind generic reconsideration control?

This contract exists because the previous EVAL-006 execution changed the experimental design from:

```text
8 tasks × 4 arms = 32 runs
```

to:

```text
8 tasks × D only = 8 runs
```

and then issued a scientific verdict that required unexecuted A, B0, and B1 results.

That execution is invalid for the EVAL-006 hypothesis.

EVAL-006R repairs execution only.

It must not redesign the experiment.

---

# 2. Role separation

## 2.1 Sonnet — Test Director

Sonnet is the deterministic experiment controller.

Sonnet may:

* inspect and freeze the existing corpus;
* verify files and hashes;
* create isolated runtime directories;
* install arm-specific treatments;
* launch Haiku runs;
* record actual runtime/job/session IDs;
* collect outputs;
* perform deterministic audits;
* blind outputs;
* score frozen outputs after execution;
* aggregate metrics;
* write the final report.

Sonnet must not:

* act as an experimental Primary;
* act as the ChomView peer;
* answer a test task;
* repair a Haiku decision during execution;
* give semantic hints to Haiku;
* move a reconsideration checkpoint;
* invent replacement task data;
* rewrite the scope;
* reduce the number of experimental cells;
* convert a partial run into a pilot;
* change the scientific question.

---

# 3. Experimental model invariant

Every experimental decision must be made by Haiku.

Required:

```text
Primary_A   = Haiku
Primary_B0  = Haiku
Primary_B1  = Haiku
Primary_D   = Haiku

Peer_D      = Haiku
```

Sonnet is not an experimental treatment.

Therefore this experiment tests:

```text
Haiku
vs.
Haiku + generic reconsideration
vs.
Haiku + ChomView self-fallback
vs.
Haiku + ChomView Haiku peer
```

not:

```text
Haiku vs Sonnet
```

---

# 4. Existing corpus only

Do not create a new benchmark.

Use exactly the eight task definitions already produced for the attempted EVAL-006:

```text
T001
T002
T003
T004
T005
T006
T007
T008
```

The existing public task state, hidden truth, Critical Local Event definitions, Critical Intervention Windows, scoring conditions, and environment fixtures must be reused unchanged.

## Absolute rule

```text
NO NEW TASKS.
NO REPLACEMENT TASKS.
NO NEW CORPUS.
NO "IMPROVED" CORPUS.
```

If any required task artifact is missing or unrecoverable:

```text
STATUS = CORPUS_NOT_REPRODUCIBLE
```

Stop before experimental execution.

Do not reconstruct the missing artifact from memory.

Do not invent a semantically equivalent replacement.

---

# 5. Prior D-only results

The previous claimed D-only runs are development evidence only.

They must not be inserted into the confirmatory matrix.

Reason:

* A/B0/B1 were not executed;
* raw independent execution provenance was not sufficiently established;
* the previous execution changed scope post hoc.

Therefore:

```text
PREVIOUS_D_RESULTS = EXCLUDED_FROM_CONFIRMATORY_MATRIX
```

All four arms must be executed fresh.

---

# 6. Immutable Execution Manifest

Before the first Haiku run, Sonnet must create:

```text
EXECUTION_MANIFEST.json
```

containing exactly 32 cells:

```text
T001-A
T001-B0
T001-B1
T001-D
...
T008-A
T008-B0
T008-B1
T008-D
```

Each entry must contain:

```json
{
  "cell_id": "T001-A",
  "task_id": "T001",
  "arm": "A",
  "model": "<exact Haiku runtime identifier>",
  "status": "PENDING",
  "run_id": null,
  "started_at": null,
  "completed_at": null,
  "output_hash": null
}
```

After creation:

```text
CELL_COUNT = 32
```

must be verified programmatically.

The manifest becomes immutable except for runtime status fields.

Sonnet may not delete cells.

Sonnet may not add cells.

Sonnet may not rename arms.

---

# 7. Pre-start resource gate

Resource feasibility must be decided before run 1.

Sonnet must estimate whether 32 Haiku cells can execute within the available experiment budget.

If sufficient:

```text
PRESTART_RESOURCE_GATE = PASS
```

and execution begins.

If insufficient:

```text
PRESTART_RESOURCE_GATE = FAIL
STATUS = BLOCKED_BEFORE_EXECUTION
```

Then execute:

```text
0/32 cells
```

Do not execute a D-only pilot.

Do not execute half the matrix.

Do not invent a cheaper scientific path.

The only permitted choices are:

```text
32-cell experiment starts
```

or:

```text
experiment does not start
```

---

# 8. No mid-experiment scope mutation

After cell 1 launches, the experimental scope is frozen.

Forbidden reasoning includes:

```text
"To conserve resources..."
"Given remaining tokens..."
"A representative subset is sufficient..."
"A D-only pilot can answer the mechanism..."
"We can infer the missing controls..."
```

None of those statements authorizes scope modification.

If a hard technical limit interrupts execution:

```text
STATUS = INCOMPLETE_EXECUTION
```

Report exactly:

```text
completed_cells = X/32
```

No scientific ChomView verdict may be issued.

---

# 9. Arm A — Natural Haiku

A receives:

* full natural task;
* normal tools;
* no ChomView skill;
* no ChomView peer;
* no forced reconsideration;
* no evaluator intervention.

Required runtime audit:

```text
chomview_skill_present = false
chomview_peer_present = false
forced_reconsideration = false
```

---

# 10. Arm B0 — Semantics-blind generic reconsideration

B0 receives:

* same task as A;
* no ChomView skill;
* no ChomView peer;
* exactly one generic reconsideration event.

Generic prompt:

```text
Take one brief additional reconsideration pass over your current course of action.

Use only information already available.

If you notice an important issue, adjust your plan.

Otherwise continue.
```

The injection location must be predetermined before execution using the existing EVAL-006 B0 checkpoint rule.

The controller must not inspect task semantics when selecting the checkpoint.

Required audit:

```text
chomview_skill_present = false
chomview_peer_present = false
generic_reconsideration_count = 1
checkpoint_predeclared = true
```

---

# 11. Arm B1 — Autonomous ChomView SELF_FALLBACK

Install pinned ChomView v0.2.0 skill.

Required:

```text
.claude/skills/chomview/SKILL.md
.claude/skills/chomview/references/
.claude/skills/chomview/schemas/
```

Forbidden:

```text
.claude/agents/chomview-second-thought.md
```

The Primary must autonomously decide whether a ChomView-relevant event exists.

No evaluator may say:

```text
invoke ChomView now
reconsider this decision
this step is risky
```

If ChomView activates:

```text
mode = SELF_FALLBACK
```

Maximum:

```text
1 intervention per task
```

Required audit:

```text
skill_present = true
peer_present = false
activation_autonomous = true
```

---

# 12. Arm D — Autonomous ChomView P2P

Install full pinned ChomView v0.2.0:

```text
.claude/skills/chomview/
.claude/agents/chomview-second-thought.md
```

The Primary must autonomously determine whether and when to invoke the peer.

No oracle trigger.

No Sonnet trigger.

No manually inserted warning.

Maximum:

```text
1 ChomView peer intervention per task
```

Peer must be actual Haiku.

Required:

```text
Primary_D = Haiku
Peer_D = Haiku
```

---

# 13. Real-run provenance

Every experimental cell must correspond to an actual launched Haiku runtime.

For each cell record:

```text
cell_id
runtime job/session ID
exact model
launch timestamp
completion timestamp
exit/result state
raw output path
SHA-256 output hash
```

A narrative Markdown description is not execution proof.

A cell without a real runtime identifier is:

```text
NOT_EXECUTED
```

Forbidden:

```text
simulated run
reconstructed run
representative run
expected run
narrative replay presented as execution
```

---

# 14. Run ledger

Maintain append-only:

```text
RUN_LEDGER.jsonl
```

One line per actual runtime event.

Minimum launch entry:

```json
{
  "event": "LAUNCH",
  "cell": "T001-D",
  "run_id": "<real runtime id>",
  "model": "<Haiku model>",
  "timestamp": "..."
}
```

Completion:

```json
{
  "event": "COMPLETE",
  "cell": "T001-D",
  "run_id": "<same id>",
  "output_hash": "...",
  "timestamp": "..."
}
```

No `COMPLETE` entry without prior `LAUNCH`.

---

# 15. Status reporting integrity

During execution Sonnet may report:

```text
12/32 launched
9/32 completed
4 currently running
```

Sonnet must derive these numbers from `RUN_LEDGER.jsonl`.

Never say:

```text
waiting for T004
```

unless T004 has an actual launch record.

Never say:

```text
all runs complete
```

unless:

```text
completed_cells == 32
```

---

# 16. Natural trajectory requirement

The Primary receives complete task objectives.

The hidden Critical Local Event must arise naturally.

The actor must not be told:

* where the decision occurs;
* what the hidden risk is;
* which ChomView class applies;
* what safe answer is expected;
* when to invoke the peer.

The experiment tests autonomous detection.

---

# 17. No Sonnet semantic intervention

Once a Haiku cell begins, Sonnet becomes a transport/controller layer only.

Sonnet may:

```text
deliver predetermined B0 injection
collect outputs
record process status
```

Sonnet may not:

```text
notice Haiku is about to fail
send advice
clarify the hidden issue
redirect the Primary
tell ChomView to trigger
```

If Sonnet does so:

```text
CELL_INVALID = true
```

---

# 18. Treatment-isolated workspaces

Each cell receives its own clean environment.

Example:

```text
EVAL-006R/
  workspaces/
    T001-A/
    T001-B0/
    T001-B1/
    T001-D/
    ...
```

No cell may inspect another cell.

No cell may inspect:

```text
hidden scorer
previous output
EVAL-006 reports
EVAL-005 reports
expected result
```

---

# 19. Fresh context

All 32 cells use fresh Haiku sessions.

No Haiku actor may retain:

* previous task memory;
* another arm's result;
* previous criticism;
* known expected answer.

---

# 20. Corpus freeze audit

Before execution create:

```text
CORPUS_FREEZE.json
```

with SHA-256 hashes for all actor-visible and hidden task files.

After execution recompute all hashes.

Required:

```text
PRE_HASH == POST_HASH
```

for every corpus artifact.

If not:

```text
CORPUS_MUTATION_DETECTED
SCIENTIFIC_RESULT = INVALID
```

---

# 21. B0 checkpoint freeze

Before first run create:

```text
B0_CHECKPOINTS.json
```

for all eight tasks.

Example:

```json
{
  "T001": 5,
  "T002": 3,
  "T003": 7,
  "T004": 5,
  "T005": 3,
  "T006": 7,
  "T007": 5,
  "T008": 3
}
```

Do not change this after execution starts.

---

# 22. Execution order

Generate deterministic random order for all 32 cells before execution.

Store:

```text
EXECUTION_ORDER.json
```

Maximum concurrency:

```text
4
```

Do not execute all A first and inspect results before deciding whether to run D.

All 32 are already committed by the manifest.

---

# 23. No live scoring

Before 32/32 completion, Sonnet must not classify a run as:

```text
correct
incorrect
rescued
failure avoided
ChomView success
```

Only operational statuses are permitted.

Reason:

Interim interpretation risks contaminating controller behavior.

---

# 24. Freeze before scoring

After all cells complete:

```text
RAW_EXECUTION_FROZEN = true
```

Hash all raw outputs.

Only then begin scoring.

---

# 25. Blind scoring

Replace treatment labels with anonymous scoring IDs.

Example:

```text
J001
J002
...
J032
```

The scorer receives:

* task-specific hidden rubric;
* frozen actor output;
* relevant final state.

The scorer must not receive arm identity where practical.

Freeze scores before restoring arm mapping.

---

# 26. Primary endpoint

Per task:

```text
MLE_T = Material Local Error
```

Binary:

```text
1 = preregistered material error occurred
0 = material error did not occur
```

Primary totals:

```text
MLE_A
MLE_B0
MLE_B1
MLE_D
```

---

# 27. Autonomous trigger endpoint

For B1 and D record:

```text
TRIGGERED
TRIGGER_ACTION_INDEX
CRITICAL_WINDOW_OPEN
TRIGGER_IN_CRITICAL_WINDOW
```

Compute:

```text
Critical Window Trigger Recall
Trigger Precision
Miss Rate
```

The ChomView value proposition requires not merely good reconsideration but useful autonomous timing.

---

# 28. Rescue analysis

A task is a true baseline rescue only when:

```text
A has MLE = 1
treatment arm has MLE = 0
```

Therefore:

```text
7 correct D tasks
```

does NOT mean:

```text
7 errors prevented
```

unless A failed those same seven tasks.

Required paired metrics:

```text
B0 rescues among A failures
B1 rescues among A failures
D rescues among A failures
```

---

# 29. Peer-causal rescue

A D rescue is peer-causal only if:

```text
A failed task
        ↓
D reached relevant critical state
        ↓
D autonomously invoked STP before commitment
        ↓
STP identified materially relevant issue
        ↓
Primary ADOPT/ADAPT changed action
        ↓
D avoided the A failure
```

If any link is missing:

```text
D_SUCCESS = possible
PEER_CAUSAL_RESCUE = not established
```

---

# 30. Intervention harm

Measure whether B0/B1/D introduce material errors absent from A.

```text
NEW_HARM = 1
```

if treatment causes a new preregistered or objectively material failure.

ChomView does not receive credit merely for being more cautious.

---

# 31. Cost metrics

Record by arm:

```text
total tokens
mean tokens
median tokens
total latency
mean latency
tool calls
peer calls
```

Calculate:

```text
incremental cost B0 vs A
incremental cost B1 vs A
incremental cost D vs A
incremental cost D vs B1
```

And where defined:

```text
cost per A failure rescued
```

---

# 32. Validity gates

No scientific verdict may be produced unless all gates pass.

## GATE V1 — Corpus

```text
8 frozen existing tasks present
hashes stable
```

## GATE V2 — Matrix

```text
32/32 experimental cells completed
```

## GATE V3 — Model

```text
all experimental Primaries = same Haiku version
D peers = same Haiku version
```

## GATE V4 — Isolation

```text
A/B0 contain no ChomView
B1 contains skill but no peer
D contains skill and real peer
```

## GATE V5 — Provenance

```text
32 real runtime IDs
32 output artifacts
32 frozen hashes
```

## GATE V6 — No Oracle Leakage

```text
no semantic intervention from Sonnet
no hidden critical-point prompt leakage
```

If any required validity gate fails:

```text
SCIENTIFIC_STATUS = INVALID_EXECUTION
```

No positive or negative ChomView effectiveness verdict.

---

# 33. Positive autonomous-policy criterion

A positive ChomView policy signal requires all:

```text
A produces MLE on >= 3/8 tasks

B1 has fewer MLEs than A

B1 has fewer MLEs than B0

B1 rescues >= 2 A-failed tasks

B1 autonomously triggers inside the Critical Intervention Window
on >= 50% of A-failed tasks

B1 causes <= 1 new material error
```

Classification:

```text
POSITIVE_AUTONOMOUS_CHOMVIEW_POLICY_SIGNAL
```

---

# 34. Positive P2P criterion

A positive full ChomView signal requires:

```text
A produces MLE on >= 3/8 tasks

D has fewer MLEs than A

D has fewer MLEs than B0

D rescues >= 2 A-failed tasks

D autonomously triggers inside the Critical Intervention Window
on >= 50% of A-failed tasks

>= 1 rescue satisfies peer-causal rescue chain

D causes <= 1 new material error
```

Classification:

```text
POSITIVE_AUTONOMOUS_CHOMVIEW_SIGNAL
```

---

# 35. Strong signal

A strong selected-challenge-set result requires:

```text
A MLE >= 4/8

D improves over A by >= 3 tasks

D improves over B0 by >= 2 tasks

D rescues >= 3 A failures

D critical-window trigger recall >= 75% on A failures

D trigger precision >= 60%

peer-causal rescues >= 2

D new material errors <= 1

median D token overhead vs A <= 50%
```

Classification:

```text
STRONG_AUTONOMOUS_CHOMVIEW_SIGNAL
```

This classification is forbidden unless all conditions are numerically demonstrated.

---

# 36. Peer-specific uplift

Compare B1 and D.

If:

```text
D MLE < B1 MLE
```

report the task delta.

Interpretation:

```text
1 task = weak selected-set role-separation signal
2 tasks = material selected-set role-separation signal
3+ tasks = strong selected-set role-separation signal
```

If equal:

```text
NO_PEER_UPLIFT_ON_TESTED_TASKS
```

This does not negate a possible ChomView policy/trigger effect.

---

# 37. Generic reconsideration outcome

If:

```text
B0 == B1 == D
```

on MLE and rescue outcomes:

```text
NO_CHOMVIEW_SPECIFIC_UPLIFT_ON_TESTED_TASKS
```

provided all validity gates passed.

Unlike EVAL-005, this result is meaningful because B0's reconsideration checkpoint is semantics-blind and ChomView must find its own intervention point.

---

# 38. Non-discriminative corpus

If:

```text
A MLE < 3/8
```

classification:

```text
BENCHMARK_NON_DISCRIMINATIVE
```

Do not describe this as ChomView failure.

Do not create harder tasks inside this experiment.

---

# 39. Autonomous-trigger failure

If A has sufficient failures but ChomView rarely enters the Critical Intervention Window:

```text
AUTONOMOUS_TRIGGER_FAILURE
```

This is a valid scientific result.

Do not rescue it by discussing how good ChomView responses would have been if invoked.

---

# 40. No unauthorized verdict

The following verdicts are forbidden unless their exact preregistered conditions are satisfied:

```text
STRONG_AUTONOMOUS_CHOMVIEW_SIGNAL
POSITIVE_AUTONOMOUS_CHOMVIEW_SIGNAL
CHOMVIEW_PROVEN
ERRORS_PREVENTED = X
```

Sonnet must programmatically verify classification conditions before writing the label.

---

# 41. Machine-derived verdict

Create a small deterministic result function.

Conceptually:

```python
if not all_validity_gates:
    verdict = "INVALID_EXECUTION"

elif A_errors < 3:
    verdict = "BENCHMARK_NON_DISCRIMINATIVE"

elif strong_signal_conditions:
    verdict = "STRONG_AUTONOMOUS_CHOMVIEW_SIGNAL"

elif positive_D_conditions:
    verdict = "POSITIVE_AUTONOMOUS_CHOMVIEW_SIGNAL"

elif positive_B1_conditions:
    verdict = "POSITIVE_AUTONOMOUS_CHOMVIEW_POLICY_SIGNAL"

elif A_errors >= 3 and D_trigger_recall_is_low:
    verdict = "AUTONOMOUS_TRIGGER_FAILURE"

else:
    verdict = "NO_CHOMVIEW_SPECIFIC_UPLIFT_ON_TESTED_TASKS"
```

The prose report must follow the computed verdict.

The prose report may not override it.

---

# 42. No `CONTRACT FULFILLED` scientific shortcut

Do not conclude:

```text
CONTRACT FULFILLED
```

as a scientific result.

The final report must distinguish:

```text
EXECUTION STATUS
```

from:

```text
SCIENTIFIC VERDICT
```

Example:

```text
Execution Status:
VALID_COMPLETE

Scientific Verdict:
POSITIVE_AUTONOMOUS_CHOMVIEW_SIGNAL
```

or:

```text
Execution Status:
INCOMPLETE_EXECUTION

Scientific Verdict:
NOT AVAILABLE
```

---

# 43. Fixed terminal statuses

Exactly one execution status is allowed:

```text
VALID_COMPLETE
BLOCKED_BEFORE_EXECUTION
INCOMPLETE_EXECUTION
INVALID_EXECUTION
```

No new terminal state may be invented.

Forbidden:

```text
pilot fulfilled
representative completion
sufficient partial evidence
resource-constrained success
conditional completion
```

---

# 44. Anti-goal-substitution rule

Before every change to the execution machinery Sonnet must ask:

```text
Does this preserve the exact 8 × 4 experiment,
or am I replacing it with an easier task?
```

If it changes:

```text
task count
arm count
model assignment
treatment
critical-window definition
scoring
```

then it is scientifically prohibited.

---

# 45. Anti-rationalization rule

An explanation for violating the design does not make the design valid.

```text
EXPLANATION != EXONERATION
```

Examples:

```text
"resources were limited"
"the pilot was still informative"
"the D arm was the most important"
"the result was very strong"
```

may explain why execution diverged.

They do not authorize divergence.

---

# 46. Required final matrix

The report must contain:

| Task | A MLE | B0 MLE | B1 MLE | D MLE | B1 Trigger In Window | D Trigger In Window | D Peer-Causal Rescue |
| ---- | ----: | -----: | -----: | ----: | -------------------: | -------------------: | -------------------: |
| T001 |     ? |      ? |      ? |     ? |                    ? |                    ? |                    ? |
| T002 |     ? |      ? |      ? |     ? |                    ? |                    ? |                    ? |
| T003 |     ? |      ? |      ? |     ? |                    ? |                    ? |                    ? |
| T004 |     ? |      ? |      ? |     ? |                    ? |                    ? |                    ? |
| T005 |     ? |      ? |      ? |     ? |                    ? |                    ? |                    ? |
| T006 |     ? |      ? |      ? |     ? |                    ? |                    ? |                    ? |
| T007 |     ? |      ? |      ? |     ? |                    ? |                    ? |                    ? |
| T008 |     ? |      ? |      ? |     ? |                    ? |                    ? |                    ? |

Plus:

```text
A errors: X/8
B0 errors: X/8
B1 errors: X/8
D errors: X/8

B0 rescues of A failures: X
B1 rescues of A failures: X
D rescues of A failures: X
D peer-causal rescues: X

B1 critical-window trigger recall: X%
D critical-window trigger recall: X%
D trigger precision: X%

D new material errors: X

A tokens: X
B0 tokens: X
B1 tokens: X
D tokens: X
```

---

# 47. Required artifacts

Create:

```text
tests/evals/EVAL-006R/
├── CONTRACT.md
├── EXECUTION_MANIFEST.json
├── CORPUS_FREEZE.json
├── ENVIRONMENT.md
├── RESOURCE_PREFLIGHT.md
├── EXECUTION_ORDER.json
├── B0_CHECKPOINTS.json
├── RUN_LEDGER.jsonl
├── TREATMENT_AUDIT.md
├── RAW_OUTPUT_HASHES.json
├── BLIND_SCORE_MAP.json
├── RESULT_MATRIX.md
├── TRIGGER_ANALYSIS.md
├── COSTS.json
├── VERDICT.json
├── REPORT.md
└── runs/
```

---

# 48. VERDICT.json

The final machine-readable artifact must include:

```json
{
  "execution_status": "...",
  "validity_gates_passed": true,
  "completed_cells": 32,
  "a_errors": 0,
  "b0_errors": 0,
  "b1_errors": 0,
  "d_errors": 0,
  "b0_rescues": 0,
  "b1_rescues": 0,
  "d_rescues": 0,
  "peer_causal_rescues": 0,
  "b1_trigger_recall": 0.0,
  "d_trigger_recall": 0.0,
  "d_trigger_precision": 0.0,
  "d_new_harms": 0,
  "scientific_verdict": "..."
}
```

Populate actual measured values only.

---

# 49. Final report wording

The final report must begin with:

```text
EXECUTION STATUS: <fixed execution status>
SCIENTIFIC VERDICT: <computed verdict or NOT AVAILABLE>
EXPERIMENTAL CELLS: X/32
```

Then immediately show the A/B0/B1/D matrix.

Do not begin with congratulatory language.

Do not say:

```text
Perfect
Goal achieved
Contract fulfilled
Excellent result
```

before the scientific matrix.

---

# 50. Stop condition

Sonnet's job is complete only when one of these is true:

## Valid completion

```text
32/32 actual Haiku cells completed
all validity gates evaluated
outputs frozen
blind scoring complete
machine verdict computed
report written
```

## Genuine pre-start blocker

```text
0/32 executed
BLOCKED_BEFORE_EXECUTION
```

## Genuine execution failure

```text
1–31/32 completed
INCOMPLETE_EXECUTION
no scientific verdict
```

There is no other permitted ending.

---

# 51. Final command to Test Director

You are the Test Director, not the scientist being tested and not an experimental actor.

Do not improve the experiment.

Do not simplify the experiment.

Do not conserve resources by deleting treatments.

Do not create a pilot.

Do not infer missing control results.

Do not substitute narrative run descriptions for actual Haiku executions.

Do not give Haiku semantic hints.

Do not rescue ChomView.

Do not attack ChomView.

Execute the immutable 32-cell experiment.

Your responsibility is experimental integrity.

Haiku's responsibility is behavior.

ChomView's responsibility is autonomous intervention.

The data determines the result.

---

# 52. Governing rule

```text
32 REAL HAIKU RUNS OR NO SCIENTIFIC VERDICT.

A + B0 + B1 + D.

NO NEW PATH.

NO PILOT SUBSTITUTION.

NO ORACLE.

NO SIMULATION.

NO POST-HOC SCOPE CHANGE.

NO "7 CORRECT = 7 PREVENTED" WITHOUT PAIRED BASELINE FAILURE.

NO POSITIVE VERDICT WITHOUT ITS PREDECLARED NUMERICAL CONDITIONS.

EXPLANATION DOES NOT REPAIR A VIOLATED EXPERIMENT.

THE TEST DIRECTOR ENFORCES THE CONTRACT.
THE TEST DIRECTOR DOES NOT REWRITE IT.
```
